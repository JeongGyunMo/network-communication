#include <stdio.h>
#include <stdlib.h>
#define BUF_SIZE 128

int main(int argc, char *argument[]){
	FILE *infile;
	FILE *outfile;
	char buf[BUF_SIZE];

	if((infile = fopen(argument[1],"r"))==NULL){
		printf("infile file open error");
		return 1;
	}
	if((outfile = fopen(argument[2],"w"))==NULL){
		printf("outfile file open error");
		fclose(infile);
		return 1;
	}
	
	int count=0,check=0,total=0,bit,sum,arr[4],error[4],i,j,t=0;

	while(fgets(buf, sizeof buf, infile) != NULL){
		bit = atoi(buf);
		arr[count++]=bit;
		if(count==4){
			for(i=1;i<=8;i*=2){
				sum+=arr[--count]*i;
			}
			for(j=0;j<4;j++)
				fprintf(outfile,"%d\n",arr[j]);
			count = 0;
			check++;
		}
		if(check==6){
			while(sum>=16)
				sum=sum/16+sum%16;
			for(i=0;i<4;i++){
				if(sum%2==0){
					t++;
					break;
				}
				sum=sum/2;
			}
			check = 0;
			total++;
			sum = 0;		
		}
	}
	printf("Number of received frames: %d\nNumber of correctly received frames: %d\n",total,total-t);
	fclose(infile);
	fclose(outfile);
	return 0;
}







