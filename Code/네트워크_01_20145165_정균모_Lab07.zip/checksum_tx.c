#include <stdio.h>
#include <stdlib.h>
#define BUF_SIZE 128

int main(int argc, char *argument[]){
	FILE *infile;
	FILE *outfile;
	char buf[BUF_SIZE];

	if((infile = fopen(argument[1],"r"))==NULL){
		printf("infile file open error");
		return 1;
	}
	if((outfile = fopen(argument[2],"w"))==NULL){
		printf("outfile file open error");
		fclose(infile);
		return 1;
	}
	
	int count=0,total=0,bit,sum=0,arr[4],i,j;

	while(fgets(buf, sizeof buf, infile) != NULL){
		bit = atoi(buf);
		arr[count++]=bit;
		if(count==4){
			for(i=1;i<=8;i*=2)
				sum+=arr[--count]*i;
			for(j=0;j<4;j++)
				fprintf(outfile,"%d\n",arr[j]);
			count = 0;
			total++;
		}
		if(total==5){
			while(sum>=16)
				sum=(sum/16)+(sum%16);			
			for(i=0;i<4;i++)
				arr[i]=0;
			for(i=0;sum>0;i++){
				arr[i]=sum%2;
				sum=sum/2;
			}
			for(j=3;j>=0;j--){
				if(arr[j]==1){
					arr[j]=0;
				}else{
					arr[j]=1;
				}
				fprintf(outfile,"%d\n",arr[j]);
			}
			total=0;
		}
	}
	fclose(infile);
	fclose(outfile);
	return 0;
}
