#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUF_SIZE 128

int main(int argc, char *argv[]) {

	FILE *infile;
	FILE *outfile;
	char buf[BUF_SIZE];

	if((infile = fopen(argument[1],"r"))==NULL){
		printf("infile file open error");
		return 1;
	}
	if((outfile = fopen(argument[2],"w"))==NULL){
		printf("outfile file open error");
		fclose(infile);
		return 1;
	}	

	char buf;
	int ascii,arr[7],i,count=0,marker[6]={0,1,1,1,1,0};
	for(i=0;i<=5;i++)
		fprintf(outfile,"%d",marker[i]);
	while(1){
		buf=fgetc(infile);
		if(buf==EOF)break;
		ascii = (int)buf;
			for(i=0;i<8;i++){
				arr[i]=0;
			}
			for(i=0;i<8;i++){
				arr[i]=ascii%2;
				ascii = ascii/2;
			}
			ascii=0;
			for(i=6;i>=0;i--){
				if(count<3){
					if(arr[i]==1){
						count++;
					}else{
						count = 0;
					}
				fprintf(outfile,"%d",arr[i]);
				}else{
					fprintf(outfile,"%d",0);
					fprintf(outfile,"%d",arr[i]);
					count = 0;
				}
			}
			count=0;
	}
	for(i=0;i<=5;i++)
		fprintf(outfile,"%d",marker[i]);
	fclose(outfile);
	fclose(infile);
	return 0;
}
