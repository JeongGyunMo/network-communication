#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUF_SIZE 128
int main(int argc, char *argv[]) {

	FILE *infile;
	FILE *outfile;
	char buf[BUF_SIZE];

	if((infile = fopen(argument[1],"r"))==NULL){
		printf("infile file open error");
		return 1;
	}
	if((outfile = fopen(argument[2],"w"))==NULL){
		printf("outfile file open error");
		fclose(infile);
		return 1;
	}	

	char c,buf;
	int integer,ascii=0,arr[7]={0,0,0,0,0,0,0},i=0,j,check=0,marker=0;
	while(1){
		buf=fgetc(infile);
		if(buf==EOF)break;
		integer = (int)buf;
		integer -='0';
		if(integer==1||check==3){
			check++;
		}else{
			check=0;
		}
		arr[i++]=integer;
		if(check ==4){
			if(integer==1){
				marker=1;
				i=6;
			}else{
				i--;
			}
			check=0;
		}
		if(marker==0&&i>=7){
			for(j=1;j<=64;j*=2){
				ascii+=arr[--i]*j;
			}
			i=0;
			check=0;
			c = (char)ascii;
			fprintf(outfile,"%c",c);
		}else if(marker==1&&i>=7){
			i=0;
			marker=0;
		}
		ascii=0;
	}
	fclose(outfile);
	fclose(infile);
	return 0;
}

















