#include <stdio.h>
#include <stdlib.h>
#include <string.h>									
#define BUF_SIZE 128								

char ref_datawords[2048][11];						//테이블을 가져올 전역변수 선언
char ref_codewords[2048][15];
void hamming_inv(char *codeword,char *dataword){	//해밍코드 복원 함수
	int i=0,j=0,check=0,hamming=0,min=10,temp=0;	
	while(i<2048){									
		for(j=0;j<15;++j){							
			if(ref_codewords[i][j]^codeword[j]){	//테이블값과 xor하여 비교
				++hamming;							//해밍변수를 증가시켜준다.
		
		}
		if(hamming < min && hamming != 0){			//해밍 변수가 0이 아니면 가장 작은 해밍 값을 저장해준다.
			min=hamming;							//min은 가장 작은 변수
			temp = i;								//위치 저장시킨다.
		}
		if(!hamming){								//만약 해밍 변수가 0이면
			for(j=0;j<11;++j)						
				dataword[j]=ref_datawords[i][j];	//dataword에다가 복사
			check=1;								//그리고 찾았다고 표시해주고
		}
		++i,hamming=0;								//각종 변수를 초기화
		}
		if(!check){										//만약 계속 체크가 0이면
			for(j=0;j<11;++j)							//가장 작은 값으로 
				dataword[j]=ref_datawords[temp][j];		//dataword에 복사시켜넣는다.
		}

	}
}

int main(int argc, char *argv[]){					
	FILE *infile;									//파일오픈 변수
	FILE *outfile;
	FILE *table;
	char buf[BUF_SIZE];
	char codeword[15]={0}, dataword[11]={0};		//배열 초기화.
	int	i=0,j=0,total=0;							


	if((infile = fopen(argv[1], "r"))== NULL){					//읽기모드로 오픈
		printf("input file open error\n");						
		return 1;												
	}

	if((outfile = fopen(argv[2],"w")) == NULL){					//쓰기모드로 오픈
		printf("output file open error. \n");					
		fclose(infile);											
		return 1;
	}
	if((table = fopen("codeword.tab","r")) == NULL){			//읽기 형식 오픈
		printf("table file open error. \n");				
		fclose(table);										
		return 1;
	}
	for(j=0;!feof(table);j++)									//테이블 끝까지
		fscanf(table,"%s %s",ref_datawords[j],ref_codewords[j]);//테이블에 있는 값들을 2차원 배열에 넣어준다.
	
	while(fgets(buf,sizeof buf,infile) != NULL){				//파일에 내용이 없을때 까지 반복
		codeword[i++]=(atoi(buf))+'0';							//buf의 값을 int형으로 불러다 넣는다.
		if(i==15){												//15개를 받았으면
			++total;											//한 프레임을 증가시키고
			hamming_inv(codeword,dataword);						//해밍코드를 원래 값으로 복원
			for(i=0;i<11;++i){									//출력
				fprintf(outfile,"%c\n",dataword[i]);
				dataword[i]=0;									//배열 초기화
			}
			i=0;												//i값 초기화
		}
	}
	printf("number of frames decoded: %d\n",total);				//프레임을 출력시켜준다.
	fclose(table);												//파일 종료
	fclose(outfile);											
	fclose(infile);												
	return 0;													
}
