#include <stdio.h>
#include <stdlib.h>
#include <string.h>					
#define BUF_SIZE 128				

void hamming(int *dataword,int *codeword){					
	int i,j;												
	for(i=0,j=0;i<15;++i){								
		if(i!=0 && i!=1 && i!=3 && i!=7)					//0,1,3,7번째 인덱스가 나오면 무시
			codeword[i]=dataword[j++];						//인덱스에 dataword 값을 복사한다.
	}

}
int main(int argc, char *argv[]){							
	FILE *infile;											//파일오픈 변수
	FILE *outfile;
	char buf[BUF_SIZE];
	if((infile = fopen(argv[1], "r"))== NULL){				//읽기모드로 오픈
		printf("input file open error\n");					
		return 1;											
		}

	if((outfile = fopen(argv[2],"w")) == NULL){				//쓰기모드로 오픈
		printf("output file open error. \n");				
		fclose(infile);										
		return 1;
	}
	
	int codeword[15]={0}, dataword[11]={0};					//배열 초기화
	int	i=0,j=0,cnt=0;										
	while(fgets(buf,sizeof buf,infile) != NULL){			//파일 내용이 없을때까지 반복
		dataword[i++]=atoi(buf);							//배열에 buf의 값을 int형으로 불러다 넣는다.
		if(i==11){											//11개씩 저장한다음
			hamming(dataword,codeword);						//hamming를 사용해 복사해준다.
			for(i=1;i<9;i*=2){								
				for(j=0,cnt=0;j<15;++j){					//각 인덱스의 체크비트를 계산해준다.
					if(((j+1)/i)%2 && i!=j+1 && codeword[j])//i에 영향을 주는 번호라면 , 그 값이 1,2,4,8이 아니고, 그값이 1이라면
						++cnt;								//카운트
				}
				codeword[i-1]=(cnt%2)? 1:0;					//홀, 짝인지 판단해서 체크비트에 입력.
			}
			for(i=0;i<15;++i){								//출력
				fprintf(outfile,"%d\n",codeword[i]);		
				codeword[i]=0;								//동시에 배열도 초기화 해준다.
				dataword[i]=0;
			}
			i=0;											//i값 초기화
		}
	}
	fclose(outfile);										//파일 닫기
	fclose(infile);											//파일 닫기
	return 0;												
}
