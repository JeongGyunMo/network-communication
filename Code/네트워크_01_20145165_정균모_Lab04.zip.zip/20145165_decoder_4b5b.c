#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define BUF_SIZE 128
void LoadTable(char(*arr4b)[5], char (*arr5b)[6],char *solu){
	int i;
	printf("%s  ->",solu);
	for(i=0;i<16;i++){
		if(strcmp(arr5b[i],solu)==0){
			strcpy(solu,arr4b[i]);
		}
	}
	printf("%s",solu);
}
int main(int argc, char *argv[]){
	FILE *signal;
	FILE *decoder;
	FILE *table;
	char arr4b[16][5];
	char arr5b[16][6];
	char solution[5];
	char buf[BUF_SIZE];
	int fi,i=0,j=0;

	if((signal = fopen(argv[1],"r"))==NULL){
		printf("file open error\n");
		return 1;
	}
	if((decoder = fopen("bitstream.rx","w"))==NULL){
		printf("file open error,\n");
		fclose(signal);
		return 1;
	}
	if((table = fopen("table.dat","r"))==NULL){
		printf("table.dat file open error.\n");
		fclose(signal);
		fclose(decoder);
		return 1;
	}
	for(;!feof(table);j++)
		fscanf(table,"%s %s",arr4b[j],arr5b[j]);
	printf("====================\n");
	while(fgets(buf, sizeof buf, signal)!=NULL){
		fi = atoi(buf);
		solution[i++]=fi+'0';
		if(i==5){
			i=0;
			solution[5] = '\0';
			LoadTable(arr4b,arr5b,solution);
			printf("\n");
			for(j=0;j<4;j++){
				fprintf(decoder,"%c\n",solution[j]);
			}
		}
	}
	printf("\n====================");
	fclose(signal);
	fclose(decoder);
	fclose(table);

	return 0;
}
