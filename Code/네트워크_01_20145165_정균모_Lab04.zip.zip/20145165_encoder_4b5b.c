#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define  BUF_SIZE 128

void LoadTable(char (*arr4b)[5], char (*arr5b)[6], char *solu){
	int i;
	
	printf("%s",solu);
	printf("  ->  ");
	for(i=0;i<16;i++){
		if(strcmp(arr4b[i],solu)==0){
			strcpy(solu,arr5b[i]);
		}
	}
	printf("%s",solu);
}

int main(int argc , char *argument[1]){
	FILE *Table;
	FILE *code;
	FILE *transition;
	char buf[BUF_SIZE];
	char arr4b[16][5];
	char arr5b[16][6];
	char solution[5];
	int n=0,j=0,fi,i;

	if((Table = fopen("table.dat","r"))==NULL){
		printf("Table file open error.");
		return 1;
	}

	if((code = fopen(argument[1],"r"))==NULL){
		printf("Table file open error.");
		fclose(Table);
		return 1;
	}

	if((transition = fopen("encoded_bitstream.tx","w"))==NULL){
		printf("Table file open error.");
		fclose(Table);
		fclose(code);
		return 1;
	}

	for(i=0;i<16;i++)
		fscanf(Table,"%s %s",arr4b[i],arr5b[i]);	
	
	printf("====================\n");
	for(i=0;i<16;i++){
		printf("%s " , arr4b[i]);
		printf("%s\n", arr5b[i]);
	}
	printf("====================\n");
	
	printf("\n====================\n");
	while(fgets(buf, sizeof buf, code)!=NULL){	
		fi = atoi(buf);
		solution[n++] = fi+'0';
		if(n==4){
			n=0;
			solution[4]='\0';
			LoadTable(arr4b,arr5b,solution);
			printf("\n");
			for(j=0;j<5;j++)
				fprintf(transition,"%c\n",solution[j]);
			
		}
	}
	printf("====================\n");

	fclose(Table);
	fclose(code);
	fclose(transition);

	return 0;
}

