﻿#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define BUF_SIZE 200 

int main(int argc, char *argument[])
{
	FILE *sigrx;
	FILE *bitrx;
	char buf[BUF_SIZE];
	int count = 0;
	float rangemin, rangemax;
	int	solution;
	int sum = 0;
	int num;
	int	plus=8;
	int co = atoi(argument[2]);
	int i,j;
	int avr;
	int quotient;

	if((sigrx = fopen(argument[1], "r")) == NULL || co < 1 || co>4) // 왜¯O곡Æi된ìE 신öA호¡Ì 파¡A일I을¡í 오¯A픈A
	{
		printf("signal file open error.");
		return 1;
	}
	if((bitrx = fopen("bitstream.rx","w")) == NULL) // 변¬?환? 할O 내ø¡í용¯e을¡í 입O력¤A할O 파¡A일I
	{
		printf("bitstream file open error.\n");
		fclose(sigrx);
		return 1;
	}

	while(fgets(buf, sizeof buf, sigrx) != NULL)
	{
		rangemin = -4;
		num = atoi(buf); //atoi를¬| 써öa서ù¡© 문ö¢ç자U를¬| 숫ùy자U로¤I 받ö¨­기¾a
		count++;	
		sum = sum + num; //신öA호¡Ì 내ø¡í용¯e을¡í 확¢ç인I하I기¾a 위¡×한N 변¬?수ùo
		if(count == 20)
		{
			avr = sum/count;
			for(i = 1; i<=4; i++){
				if(i!=4){
					rangemin = rangemin/2;
					plus = 8/i;
				}else{
					plus = 1;
					rangemin = -0.5;
				}
				if(avr<-4){
					for(i=0;i<=co;i++)
					{
						fprintf(bitrx,"%d\n",0);
					}
					break;
				}else if(avr > 15.5){
					for(i=0;i<-co;i++){
						fprintf(bitrx,"%d\n",1);
					}
					break;
				}
				if(co == i){
					for(; rangemin<=14.5; rangemin=rangemin+plus){
						rangemax = rangemin + plus;
						if(rangemin<avr && rangemax>avr){
							solution = (rangemin+rangemax)/2;
							for(j = 1; j<=co; j++){
								if(solution != 1){
									quotient = solution/(8/j);
									fprintf(bitrx,"%d\n",quotient);
									solution= solution%(8/j);
				
								}else if(j==co){
									fprintf(bitrx,"%d\n",1);
								}
							}
						}
						}
					}
				}
			count = 0;
			sum = 0;
			avr = 0;
	}
		}
	fclose(sigrx);// 파¡A일I 닫¥Y기¾a
	fclose(bitrx);
	return 0;
}
