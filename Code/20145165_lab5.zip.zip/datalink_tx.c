#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#define BUF_SIZE 128

int main(int argc, char *argument[])
{
	FILE *data;
	FILE *code;
	char buf[BUF_SIZE];
	int bit;
	int count = 0;
	int sum=0;
	int i;
	int solution[7];
	if((data = fopen(argument[1], "r")) == NULL)
	{
		printf("bitstream file open error");
				return 1;
	}

	if((code = fopen(argument[2],"w")) == NULL)
	{
		printf("signal file open error.\n");
		fclose(data);
		return 1;
	}
	
	while(fgets(buf, sizeof buf, data) != NULL)
	{
		bit = atoi(buf);
		sum +=bit;
		solution[count]=bit;
		if(count++ == 6){
			solution[count]=sum%2;
			for(i=0; i <= 7; i++){
				fprintf(code,"%d\n",solution[i]);
			}
			count = 0;
			sum = 0;
			solution[7] = '\n';
		}
	}
	fclose(data);
	fclose(code);
	return 0;
}

