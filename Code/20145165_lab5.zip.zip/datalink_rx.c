#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define BUF_SIZE 128

int main(int argc, char *argument[])
{
	FILE *code;
	FILE *data;
	char buf[BUF_SIZE];
	int num;
	int i = 0;
	int sum=0;
	int sub=0;
	int count = 1;
	int solutioncount = 0;

	if((code = fopen(argument[1], "r")) == NULL)
	{
		printf("codedstream file open error.");
		return 1;
	}
	if((data = fopen(argument[2],"w")) == NULL)
	{
		printf("datastream file open error.\n");
		fclose(code);
		return 1;
	}

	while(fgets(buf, sizeof buf, code) != NULL)
	{
		if(i++ == 7)
		{
			count++;
			sub++;
			num = atoi(buf);
			sum += num;
			if(sum%2==0)
			{
				solutioncount++;
			}
			sum=0;
			i=0;
		}else{
			count++;
			num= atoi(buf);
			sum +=num;
			fprintf(data,"%d\n",num);
		}
	}
	printf("Number of received codewords: %d\n",(count-sub)/7);
	printf("Numver of correctly received codewords: %d\n",solutioncount);
	fclose(code);
	fclose(data);
	return 0;
}
	
