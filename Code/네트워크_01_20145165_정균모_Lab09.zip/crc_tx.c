#include <stdio.h>
#include <stdlib.h>
#include <string.h>					//string 관련 함수를 사용하기위한 헤더파일

#define BUF_SIZE 128				//BUF_SIZE로 되있는것들은 다 128로바꾼다.
int main(int argc, char *argv[]){	//메인시작
	FILE *infile;					//파일포인터 선언
	FILE *outfile;
	char bit[7];					//datastream.tx에서 읽어온 비트를 담아줄 배열이다.
	char gen[4];					//실행시 주는 값을 받아줄 배열이다.
	char buf[BUF_SIZE];
	if((infile = fopen(argv[1], "r"))== NULL){				//infile에 datastream.tx를 읽기모드로 불러온다.  이게 없으면
		printf("input file open error\n");					//에러 메시지를 출력하고
		return 1;											//1을 반환하며 종료한다
	}

	if((outfile = fopen(argv[2],"w")) == NULL){				//outfile에 codedstream.tx를 쓰기모드로 불러오고 이값이 null이면
		printf("output file open error. \n");				//오류내용을 출력하고
		fclose(infile);										//infile을 종료시킨후 1을 반환하며 종료한다.
		return 1;
	}
	
	if(argv[3]==NULL){										//3번째 인자가 없으면
		printf("argv[3] file open error. \n");				//오류내용을 출력하고
		return 1;											//종료한다.
	}
	strcpy(gen,argv[3]);									//3번째 인자를 char타입의 배열인 gen에 복사한다.
	
	int i=0,j=0;											//각종 변수 선언
	while(fgets(buf, sizeof buf , infile) != NULL){			//반복문 시작 // fgets를 사용해서 buf에 buf사이즈만큼 infile에 있는 내용을 파일이 끝날때까지 불러온다.
		bit[i++]=atoi(buf);									//비트의 i번째값에 buf의 값을 int형으로 불러다 넣고
		if(!(i%4)){											//4개씩 저장한다음
			bit[4]=0,bit[5]=0,bit[6]=0;						//뒤 3자리에 0을 집어넣는다.
			for(i=0;i<4;++i){								//그리고 앞자리 4개를 먼저 outfile에다 적고
				fprintf(outfile,"%d\n",bit[i]);
			}
			for(i=0;i<4;++i){								//계산을 시작한다. 계산은 4번만 진행되고
				if(bit[i]){									//bit의 i번째 값이 1이면
					for(j=i;j<i+4;++j){						//j는 i가 되면서 i+4까지돌게된다. 그래야배열의  앞을 보지않고 계산을 해주기때문이다.
						bit[j]=0;							//j번째는 계산을 안하고
						bit[j+1]^=(gen[1]-'0');				//j+1,2,3번째와 나눠줄값 이랑 xor연산을 해주고 다시 bit에 넣어준다.
						bit[j+2]^=(gen[2]-'0');
						bit[j+3]^=(gen[3]-'0');	
						break;								//이 작업이 끝나면 바로 break 해주고
					}
						
				}
			}
			for(i=4;i<7;++i){								//나머지 뒤의 3자리를 출력해준다.
				fprintf(outfile,"%d\n",bit[i]);				//이럼 0~6번째 인덱스의 모든값이 outfile에 출력된다.
			}
			i=0;											//i값 초기화 후 반복
		}
	}
	fclose(outfile);										//파일 종료
	fclose(infile);											//파일 종료
	return 0;												//crc_tx.c  종료
}

