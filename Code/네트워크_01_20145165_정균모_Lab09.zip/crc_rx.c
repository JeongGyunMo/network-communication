#include <stdio.h>
#include <stdlib.h>
#include <string.h>					//string 관련 함수를 사용하기위한 헤더파일

#define BUF_SIZE 128				//BUF_SIZE로 되있는것들은 다 128로바꾼다.
int main(int argc, char *argv[]){	//메인시작
	FILE *infile;					//파일포인터 선언
	FILE *outfile;
	char bit[7];					//codedstream.rx에서 받아올 값 7개를 저장하기 위한 배열
	char gen[4];					//입력받은 값을 저장해줄 배열
	char buf[BUF_SIZE];
	if((infile = fopen(argv[1], "r"))== NULL){				//infile에 datastream.tx를 읽기모드로 불러온다.  이게 없으면
		printf("input file open error\n");					//에러 메시지를 출력하고
		return 1;											//1을 반환하며 종료한다
	}

	if((outfile = fopen(argv[2],"w")) == NULL){				//outfile에 codedstream.tx를 쓰기모드로 불러오고 이값이 null이면
		printf("output file open error. \n");				//오류내용을 출력하고
		fclose(infile);										//infile을 종료시킨후 1을 반환하며 종료한다.
		return 1;
	}
	
	if(argv[3]==NULL){										//만약 3번째 인자가 없으면
		printf("argv[3] file open error. \n");				//오류내용을 출력하고
		return 1;											//종료한다.
	}
	strcpy(gen,argv[3]);									//3번째 파일을 char타입 배열인 gen에다가 복사한다.
	int i=0,j=0,total=0,error=0;							//각종 변수 선언 및 초기화
	while(fgets(buf, sizeof buf , infile) != NULL){			//반복문 시작 // fgets를 사용해서 buf에 buf사이즈만큼 infile에 있는 내용을 파일이 끝날때까지 불러온다.
		bit[i++]=atoi(buf);									//bit의 i번째에 buf의 내용을 정수로 바꿔서 저장하고
		if(!(i%7)){											//i가 7이 되면 배열에 7개를 받게 된거니깐
			++total;										//한 프레임을 받은거니깐 total값을 증가시켜주고
			for(i=0;i<4;++i){								//그리고 뒤의 3개를 띠어주고
				fprintf(outfile,"%d\n",bit[i]);				//outfile에 출력해준다.
			}
			for(i=0;i<4;++i){								//i는 0~3까지 4번 계산을 시작한다.
				if(bit[i]){									//bit의 i값이 1이 되기 전까지는 모두 버렸다가 1이 된다면
					for(j=i;j<i+4;++j){						//j는 i값으로 하여 앞에 저장됐던 배열을 안건드리게 만들어주고 i+4만큼 반복하게된다.
						bit[j]=0;							//첫번째 값끼리는 계산할 필요가 없기 때문에 0으로 아애 만들어주고
						bit[j+1]^=(gen[1]-'0');				//j+1,2,3과 입력받은 값 1,2,3번째랑 xor연산을해서 각 인덱스에 다시 저장해준다.
						bit[j+2]^=(gen[2]-'0');
						bit[j+3]^=(gen[3]-'0');	
						break;								//이게 끝나면 바로 반복문을 종료하고
					}
				}
			}
			if(bit[4] || bit[5] || bit[6])					//만약 bit의 4,5,6 인덱스에 1이 하나라도 있으면
				++error;									//에러를 증가시킨다.
			i=0;											//i를 다시 초기화 시켜준다.
		}
	}
	printf("number of frames decoded: %d\n",total);			//total값과
	printf("numver of frames with errors : %d\n",error);	//에러값을 출력시켜준다.
	fclose(outfile);										//파일 종료
	fclose(infile);											//파일 종료
	return 0;												//crc_rx.c  종료
}
