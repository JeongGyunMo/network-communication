#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#define BUF_SIZE 128

int main(int argc, char *argument[]){
	FILE *bitstream;
	FILE *signal;
	char buf[BUF_SIZE];
	int bit;
	int bolt;
	int i;
	int count = 0;

	if((bitstream = fopen(argument[1], "r"))==NULL){
		printf("bitstream file open error.\n");
		return 1;
	}

	if((signal = fopen("signal.tx","w"))==NULL){
		printf("signal file open error.\n");
		fclose(bitstream);
		return 1;
	}

	while(fgets(buf, sizeof buf, bitstream) != NULL){
		bit = atoi(buf);
			if(bit == 0 && count ==0){
				bolt = 5;
				for(i=0; i<20;i++)
				fprintf(signal,"%d\n",bolt);
			}else if(bit == 1 && count ==0) {
				bolt = -5;
				for(i=0; i<20;i++)
					fprintf(signal,"%d\n",bolt);
				}
			if(count != 0){
				if(bit == 0){
					bolt = bolt * 1;
					for(i=0;i<20;i++)
						fprintf(signal, "%d\n",bolt);
				}else{
					bolt = bolt * -1;
					for(i=0;i<20;i++)
						fprintf(signal, "%d\n",bolt);
				}
			}
			count++;
	}
	fclose(bitstream);
	fclose(signal);
	return 0;
}
