#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define BUF_SIZE 128

int main(int argc, char *argument[])
{
	FILE *sigrx;
	FILE *bitrx;
	char buf[BUF_SIZE];
	int count = 0;
	int sum = 0;
	int num, avr, bolt, solution;
	int judge = 0;
	int backnum;

	if((sigrx = fopen(argument[1], "r")) == NULL) 
	{
		printf("signal file open error.");
		return 1;
	}
	if((bitrx = fopen("bitstream.rx","w")) == NULL) 
	{
		printf("bitstream file open error.\n");
		fclose(sigrx);
		return 1;
	}

	while(fgets(buf, sizeof buf, sigrx) != NULL)
	{
		num = atoi(buf); 
		count++; 
		sum += num; 
		if(count == 20)
		{
			avr = sum / 20;
				if(avr >= 0 && judge == 0)
				{
					solution = 0;
					backnum = 5;
					fprintf(bitrx,"%d\n",solution);
				}
				else if(avr <= 0 && judge == 0){
					solution = 1;
					backnum = -5;
					fprintf(bitrx,"%d\n",solution);
				}	
			if(avr >= 0 && judge != 0){
					bolt = 5;
					if(backnum == bolt){
					solution = 0;
					fprintf(bitrx,"%d\n",solution);
					}else{
						solution = 1;
						fprintf(bitrx, "%d\n",solution);
						backnum = bolt;
					}
			}else if(avr <=0 && judge != 0){
				bolt = -5;
				if(backnum == bolt){
					solution = 0;
					fprintf(bitrx,"%d\n",solution);
				}else{
					solution = 1;
					fprintf(bitrx, "%d\n",solution);
					backnum = bolt;
				}
			}
			sum = count = 0;
			judge++;
		}
	}
	fclose(sigrx);
	fclose(bitrx);
	return 0;
}
	
